"use strict";

(() => {
  const status = document.getElementById("load-status");
  const touch = window.matchMedia("(pointer: coarse)").matches;
  if (touch) document.body.classList.add("touch-controls");
  const saveKey = "snap-cartridge-v1";
  const validSave = (save) => save && save.path === "/data/saves/Gambatte/snap.srm"
    && Array.isArray(save.bytes) && save.bytes.length === 8192
    && save.bytes.every(n => Number.isInteger(n) && n >= 0 && n <= 255)
    && save.bytes[0] === 67 && save.bytes[1] === 75 && save.bytes[2] === 1;
  const saveNow = () => {
    if (window.EJS_emulator?.started) window.EJS_emulator.gameManager.saveSaveFiles();
  };

  Object.assign(window, {
    EJS_player: "#game",
    EJS_core: "gambatte",
    EJS_controlScheme: "gb",
    EJS_gameName: "Snap!",
    EJS_gameUrl: "roms/snap.gbc",
    EJS_pathtodata: "emulatorjs/data/",
    EJS_language: "ja-JA",
    EJS_disableAutoLang: false,
    EJS_startOnLoaded: false,
    EJS_startButtonName: "プレイする",
    // EmulatorJS resolves this image relative to EJS_pathtodata.
    EJS_backgroundImage: "../../assets/title.png",
    EJS_backgroundBlur: false,
    EJS_backgroundColor: "#122f36",
    EJS_color: "#e96750",
    EJS_volume: 0.55,
    // itch.io does not need SharedArrayBuffer / cross-origin isolation headers.
    EJS_threads: false,
    EJS_defaultControls: {
      0: {
        0: { value: "z", value2: "BUTTON_2" },
        2: { value: "shift", value2: "SELECT" },
        3: { value: "enter", value2: "START" },
        4: { value: "up arrow", value2: "DPAD_UP" },
        5: { value: "down arrow", value2: "DPAD_DOWN" },
        6: { value: "left arrow", value2: "DPAD_LEFT" },
        7: { value: "right arrow", value2: "DPAD_RIGHT" },
        8: { value: "x", value2: "BUTTON_1" }
      },
      1: {}, 2: {}, 3: {}
    },
    EJS_defaultOptions: {
      "virtual-gamepad": touch ? "enabled" : "disabled",
      "save-save-interval": "30",
      "screenshotSource": "retroarch",
      "shader": "disabled"
    },
    EJS_VirtualGamepadSettings: [
      { type: "button", text: "A", id: "a", location: "right", left: 76, top: 30, bold: true, input_value: 8 },
      { type: "button", text: "B", id: "b", location: "right", left: 10, top: 65, bold: true, input_value: 0 },
      { type: "dpad", id: "dpad", location: "left", left: "50%", top: "50%", joystickInput: false, inputValues: [4, 5, 6, 7] },
      { type: "button", text: "START", id: "start", location: "center", left: 67, fontSize: 11, block: true, input_value: 3 },
      { type: "button", text: "SELECT", id: "select", location: "center", left: -6, fontSize: 11, block: true, input_value: 2 }
    ],
    EJS_Buttons: {
      playPause: true, restart: true, fullscreen: true, mute: true, volume: true,
      settings: true, gamepad: true, saveSavFiles: true, loadSavFiles: true,
      saveState: false, loadState: false, quickSave: false, quickLoad: false,
      screenshot: true, screenRecord: false, cheat: false, cacheManager: false,
      exitEmulation: false
    },
    EJS_ready: () => {
      status.hidden = true;
      // IDBFS autoPersist is asynchronous. Keep a synchronous cartridge backup
      // on the save event, so an immediate reload after a result cannot lose it.
      window.EJS_emulator.on("saveSaveFiles", bytes => {
        if (!bytes) return;
        const save = { path: window.EJS_emulator.gameManager.getSaveFilePath(), bytes: Array.from(bytes) };
        if (!validSave(save)) return;
        try { window.localStorage.setItem(saveKey, JSON.stringify(save)); } catch (_) {}
      });
      window.EJS_emulator.on("saveDatabaseLoaded", () => {
        try {
          const save = JSON.parse(window.localStorage.getItem(saveKey));
          if (validSave(save)) window.EJS_emulator.gameManager.writeFile(save.path, new Uint8Array(save.bytes));
        } catch (_) {}
      });
    },
    EJS_onGameStart: () => {
      status.hidden = true;
      window.setInterval(saveNow, 5000);
    }
  });

  if (window.location.protocol === "file:") {
    status.textContent = "HTTPサーバーで開いてください。make web-serve で起動できます。";
    status.classList.add("error");
    return;
  }
  const loader = document.createElement("script");
  loader.src = "emulatorjs/data/loader.js";
  loader.onerror = () => {
    status.hidden = false;
    status.classList.add("error");
    status.textContent = "読み込めませんでした。ページを再読み込みしてください。";
  };
  document.body.appendChild(loader);
  document.addEventListener("visibilitychange", () => { if (document.hidden) saveNow(); });
  window.addEventListener("pagehide", saveNow);
})();
